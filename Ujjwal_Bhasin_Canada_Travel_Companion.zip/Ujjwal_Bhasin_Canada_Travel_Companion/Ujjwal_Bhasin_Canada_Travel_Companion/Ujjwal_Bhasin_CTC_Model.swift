//
//  Ujjwal_Bhasin_CTC_Model.swift
//  Ujjwal_Bhasin_Canada_Travel_Companion
//
//  Created by Ujjwal Bhasin on 2019-06-18.
//  Copyright © 2019 Ujjwal Bhasin. All rights reserved.
//

import Foundation
    class Ujjwal_Bhasin_CTC_Model {
    
        var greetingsArray:[String] =
            ["How ya doing?","Bonjour","Whadder yup to?","Howdy!"]
        
        func  greetingsArray(_ tag: Int){
            
        }
}

