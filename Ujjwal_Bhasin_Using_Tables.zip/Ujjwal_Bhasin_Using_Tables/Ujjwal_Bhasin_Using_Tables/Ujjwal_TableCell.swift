//
//  Ujjwal_TableCell.swift
//  Ujjwal_Bhasin_Using_Tables
//
//  Created by Ujjwal Bhasin on 2019-08-13.
//  Copyright © 2019 Ujjwal Bhasin. All rights reserved.
//

import UIKit

class Ujjwal_TableCell: UITableViewCell {

    @IBOutlet weak var myCell: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
