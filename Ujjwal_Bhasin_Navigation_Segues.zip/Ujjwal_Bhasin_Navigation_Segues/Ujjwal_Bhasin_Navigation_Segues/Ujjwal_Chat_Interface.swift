//
//  Ujjwal_Chat_Interface.swift
//  Ujjwal_Bhasin_Navigation_Segues
//
//  Created by Ujjwal Bhasin on 2019-08-13.
//  Copyright © 2019 Ujjwal Bhasin. All rights reserved.
//

import UIKit

class Ujjwal_Chat_Interface: UIViewController {

    @IBAction func btnOne(_ sender: Any) {
    }
    @IBAction func btnTwo(_ sender: Any) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
