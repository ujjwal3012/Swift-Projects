//
//  ViewController.swift
//  Ujjwal_Bhasin_MapKit_Usage
//
//  Created by Ujjwal Bhasin on 2019-08-13.
//  Copyright © 2019 Ujjwal Bhasin. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {

    
    @IBOutlet weak var mapview: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    let rioDeJanerioLatitude = -22.970722
    let rioDeJanerioLongitude = -43.182365
    let rioDeJanerioLocation = CLLocationCoordinate2D(latitude: rioDeJanerioLatitude, longitude: rioDeJanerioLongitude)
    let delta = 0.2
        let span = MKCoordinateSpan(latitudeDelta: delta, longitudeDelta: delta)
    let regionToShow = MKCoordinateRegion(center: rioDeJanerioLocation, span: span)
    mapview.setRegion(regionToShow, animated: true)
    }


}

